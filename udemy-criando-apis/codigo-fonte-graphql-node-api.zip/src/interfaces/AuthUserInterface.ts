export interface AuthUser {

    id: number;
    email?: string;

}